Image Generator app using OPEN AI API.
Enter any text you want and generate image from that text.

![Screenshot_20230319_172535](https://user-images.githubusercontent.com/60041910/226173870-6ab6bddf-b149-40fe-a82e-caa11b96ab32.png)


How to use:
Clone the repo
Get the API key from OPEN AI website.
In MainActivity.java change YOUR API KEY and run the app.

